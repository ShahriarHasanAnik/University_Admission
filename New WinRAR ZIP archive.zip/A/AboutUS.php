<?php session_start();
require('includes/config.php');
?>

<!DOCTYPE html>
<html>
    <head>
	<meta charset="UTF-8">
    <link rel="stylesheet" href="Searchboxstyle.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Home</title>
        <link rel="stylesheet" type="text/css" href="Styles/Stylesheet.css" />
		<link rel="stylesheet" href="Styles/Searchboxstyle.css">
		<link rel="stylesheet" href="Styles/style.css">
    </head>
    <body>
	<?php
			include("includes/menu.inc.php");
		?>
      <h1>About Us</h1>
      <p>______________________________________________________________________
	 
         </p>
    </div>
  </header>
  <div class="pimg2">
    <section class="section section-b">
    <div class="container">
  
      <p><h1><br><font color=#87ceeb>Team Members:</font></h1></p>
      <p><img src="photo\ratun.jpg " width="400" height="400">
	  <h2> Ratun Rahaman <br>
	           IUT,<br>
			   CSE(SWE)-17 <br>
			   ID:170042011 <br>
	  </h2>
        </p>
		<br><br>
    </div>
	<div class="pimg2">
    <section class="section section-b">
    <div class="container">
  
      <p><h1><br><font color=#87ceeb></font></h1></p>
      <p>  <p><img src="photo\wahid.jpg " width="400" height="400">
	  <h2> Md.Wahid Shikder <br>
	           IUT,<br>
			   CSE(SWE)-17 <br>
			   ID:170042089 <br>
	  </h2>
        </p>
		<br><br>
    </div>
	
	<div class="pimg2">
    <section class="section section-b">
    <div class="container">
  
      <p><h1><br><font color=#87ceeb></font></h1></p>
      <p>  <p><img src="photo\nawshad.jpg " width="400" height="400">
	  <h2> Nawsad Rahmatullah <br>
	           IUT,<br>
			   CSE(SWE)-17 <br>
			   ID:170042084 <br>
	  </h2>
        </p>
		<br><br>
    </div>
	
  </section>
  </div>
<div class="pimg1">
  </div>

  <section class="What Is New">
    <div class="container2">
      <p><b>All rights reserved</b>
        </p>
    </div>
  </section>
    </body>
</html>