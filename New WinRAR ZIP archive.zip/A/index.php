<?php session_start();
require('includes/config.php');
?>

<!DOCTYPE html>
<html>
    <head>
	<meta charset="UTF-8">
    <link rel="stylesheet" href="Searchboxstyle.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Home</title>
        <link rel="stylesheet" type="text/css" href="Styles/Stylesheet.css" />
		<link rel="stylesheet" href="Styles/Searchboxstyle.css">
		<link rel="stylesheet" href="Styles/style.css">
    </head>
    <body>
	<?php
			include("includes/menu.inc.php");
		?>
      <h1>Welcome to Online Library!</h1>
      <p>______________________________________________________________________
	  Looking for free ebooks? <font color="#a29bfe">"Online Library"</font> provides over 60,000 free books
			and features limited-time offers for the best free books in over twenty genres, from both top-tier
			publishers and critically-acclaimed independent authors. These free ebooks are available on all 
			devices, including Kindle, Nook, iPad, and Android. Check out some of our current selections for free!
         </p>
    </div>
  </header>
  <div class="pimg2">
    <section class="section section-b">
    <div class="container">
  
      <p><h1><br><font color=#87ceeb>Can't Find More Books?</font></h1></p>
      <p><h2>Hi there! If you are tired looking for new books but cant find one, dont worry! We have sorted all the 
			books in different catagories! Also just select your favourite books as favourite
			so we can find books that you will love!</h2>
        </p>
		<br><br>
    </div>
  </section>
  </div>
<div class="pimg1">
  </div>

  <section class="What Is New">
    <div class="container2">
      <p><b>All rights reserved</b>
        </p>
    </div>
  </section>
    </body>
</html>
