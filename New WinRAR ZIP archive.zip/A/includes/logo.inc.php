<marquee  direction="right" behavior="alternate"><h1>Latest News</h1></marquee>
