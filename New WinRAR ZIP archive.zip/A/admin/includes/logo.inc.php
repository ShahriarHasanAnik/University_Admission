<marquee  direction="right" behavior="alternate"><h1>Admin Panel</h1></marquee>
