</div>
<div class="pimg1">
  </div>

  <section class="What Is New">
    <div class="container2">
      <p><b>All rights reserved</b>
        </p>
    </div>
  </section>
    </body>
</html>
